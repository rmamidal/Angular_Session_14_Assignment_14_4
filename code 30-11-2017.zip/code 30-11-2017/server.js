
var request = require('request');
var express = require('express');
var cors = require('cors');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var fs = require('fs');
var http = require('http');
var bodyParser = require('body-parser');
var environment = require('./environment.json');

//var privateKey  = fs.readFileSync('./ssl/private.pem', 'utf8');
//var certificate = fs.readFileSync('./ssl/public.pem', 'utf8');

//var credentials = {key: privateKey, cert: certificate};

// Faster server renders w/ Prod mode (dev mode never needed)
//enableProdMode();

// Express server
const app = express();

const PORT =  8080;


/* - Example Express Rest API endpoints -
  app.get('/api/**', (req, res) => { });
*/
// Body-Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
// Cors
app.use(cors());
app.use(cookieParser());
// Add headers

app.get('/api/*', (req,res)=>{
  var auth = "Basic " + new Buffer(environment.userName + ":" + environment.pwd).toString("base64");
  var urlData = environment.apiUrl+req.url;
  const options = {
    url: urlData,
    method: 'GET',
    rejectUnauthorized: false,
    requestCert: false,
    headers: {
      'Content-Type':'application/hal+json',
      'Authorization' : auth  
    } 
  };
  console.log(urlData);
  request(options, function(error, response, body){
    if (error) return res.status(500).send({message: error.message});
    //to write data into redis database
    //redisController.writeToCache(body,req,res,next);
    res.status(response.statusCode).send(body);
    
  });
}); 

http.createServer(app).listen(8080, function () {
  console.log('Started!');
});