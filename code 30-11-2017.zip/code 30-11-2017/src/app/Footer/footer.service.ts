import {Injectable} from '@angular/core';
import {Http,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../base.service';
import {AppService} from '../Service/app.service';

@Injectable()
export class FooterService extends BaseService  {
    constructor(private _service:AppService, private _http:Http){
            super();
    }

    public FindFooterLinkks():Observable<any[]>{
        let url= this.BaseUrl + 'samplefooterresponse.json';    
        return this._http
        .get(url)
        .map((response:any) => {
            return response
        })        
    }

    // social media
    public FindSocialMediaLinks():Observable<any[]> {
        
        let url= "/api/menu_details/footer-icons?_format=json";
        let _headers = new Headers();
        _headers.append("Content-Type","application/hal+json");
        let options = new RequestOptions({ headers: _headers });

        return this._service
        .get(url)
        .map((response:any) => {            
            return response
        })        
    }
   
    public FindFooter_New(){   
        let url= "/api/menu_details/footer?_format=hal_json";
        let _headers = new Headers();
        _headers.append("Content-Type","application/hal+json");
        let options = new RequestOptions({ headers: _headers });
        
        return this._service
        .get(url)
        .map((response:any) => {                
            return response
        }) 
       //return this.FindFooter_New1();
    }
   
}