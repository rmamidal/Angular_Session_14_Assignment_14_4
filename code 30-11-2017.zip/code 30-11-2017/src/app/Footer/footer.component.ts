import { Component,OnInit } from '@angular/core';
import {FooterService} from './footer.service'
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {ContentNavigation} from '../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../Service/redirection.service'

@Component({
  selector: 'footer-component',
  templateUrl: './footer.component.html',
  providers:[FooterService,RedirectionService]
})

export class FooterComponent implements OnInit {
  FooterNavigationInfo:any;  
  RoutesData: any;

  constructor(private _service:FooterService,
    private _redirectionService:RedirectionService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
  ){
  }

  ngOnInit(){
    this.Init();
  }

  private Init(){
    this._service.FindFooter_New().subscribe((data)=>{
        this.FooterNavigationInfo = data;  
    });
  }

  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}
