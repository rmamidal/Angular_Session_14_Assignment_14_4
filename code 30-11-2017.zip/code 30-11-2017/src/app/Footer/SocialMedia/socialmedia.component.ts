import { Component,OnInit, Input } from '@angular/core';
import {FooterService} from '../footer.service'
import {SocialMediaLinks} from './socialmedialinks.service'
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
import {ContentNavigation} from '../../Model/contentnavigation.model'

@Component({
  selector: 'socialmedialinks-component',
  templateUrl: './socialmedialinks.component.html',
  providers:[SocialMediaLinks, RedirectionService]
})


export class SocialMediaComponent implements OnInit {
  public SocialMediaLinksInfo = null;  
  @Input() data: any;
  constructor(private _service:FooterService,
    private _redirectionService:RedirectionService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute){
  }

  ngOnInit(){
    this.Init();  
  }

  private Init(){
    this._service.FindSocialMediaLinks().subscribe((data)=>{
    this.SocialMediaLinksInfo = data; 
    });
  }
  public ManageContentNavigation(data:any){  
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);
  }

}
