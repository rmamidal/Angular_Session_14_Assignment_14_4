import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';

@Injectable()
export class SocialMediaLinks extends BaseService  {
    constructor(private _http:Http){
        super();
    }

    public Find(apiURL:string):Observable<any[]>{
        let url= this.BaseUrl + 'samplesocialmedia.json';    
        //let url= this.BaseUrl + apiURL;    
        return this._http
        .get(url)
        .map((response:any) => {
            return response
        })        
    }
 
}