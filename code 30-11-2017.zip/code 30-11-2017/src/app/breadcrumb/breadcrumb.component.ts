import { Component,OnInit,Input } from '@angular/core';
import {BreadcrumbModel} from '../Model/breadcrumb.model';
import {BreadcrumbService} from './breadcrumb.service'
import {ContentNavigation} from '../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../Service/redirection.service'

@Component({
  selector: 'breadcrumb-component',
  templateUrl: './breadcrumb.component.html',
  providers:[BreadcrumbService,RedirectionService]
})

export class BreadcrumbComponent implements OnInit {

    @Input() apiUrl: any;
    public BreadcrumbResponse = null;
    public BreadcrumbInfo:Array<BreadcrumbModel>;
    constructor(private _service:BreadcrumbService,
                private _router:Router,
                private _activatedRoute:ActivatedRoute,
                private _redirectionService:RedirectionService
    ){
        this.BreadcrumbInfo = Array<BreadcrumbModel>();
    }
   
    ngOnInit(){
       this.Init();
    }

    private Init() {  
        let url = "/"+ this.apiUrl + "?_format=hal_json";             
        this._service.Find(url).subscribe(
        (data:any)=>{                 
              if(data.Items!=null){
                let length = data.Items.length;
                data.Items.forEach((item:any,index) => {
                    let obj = new BreadcrumbModel(index,item.title,item.api,item.alias,length);                    
                    this.BreadcrumbInfo.push(obj);
                });
              }             
        }); 
    }

    public ManageContentNavigation(data:any){                         
        if(data!=null){ 
            let obj= new ContentNavigation().ManagePageRedirection(data);
            this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
        }
    }
}

