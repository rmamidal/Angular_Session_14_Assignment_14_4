import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './containers/app/app.component';
import { LayoutComponent } from './components/layout/layout.component';
import { RouterModule } from "@angular/router";

@NgModule({
	imports: [
		CommonModule,
		RouterModule
	],
	declarations: [
		AppComponent,
		LayoutComponent
	],
	exports: [
		AppComponent,
	],
})
export class CoreModule {
}
