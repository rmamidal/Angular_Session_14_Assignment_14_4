import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UniversalInterceptor } from './universal.interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import {router} from './app.router';
import { Router } from '@angular/router';

import { FormsModule } from '@angular/forms';
import {NgxCarouselModule} from 'ngx-carousel';
import { SharedModule } from '../app/shared/shared.module';
import { StoreModule } from '../app/store/store.module';
import {AppService} from './Service/app.service'
import {RoutesService} from "./Service/routes.service";
import {NotificationPopupEvent} from "./Service/broadcaster.service";

import {Broadcaster} from "./Model/broadcaster.model";
import {LocationStrategy, HashLocationStrategy} from "@angular/common";

//import all component...
import { AppComponent } from './app.component';
import { HomeComponent } from './Home/home.component';
import { HeaderComponent } from './Header/header.component';
import { SubNavigationComponent } from './Header/SubNavigation/subnavigation.component';
import { FooterComponent } from './Footer/footer.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { SocialMediaComponent } from './Footer/SocialMedia/socialmedia.component';

//import all widget...
import {ProductCardComponent} from './Widget/ProductCard/productcard.component';
import {HeroBannerLeftLayoutComponent} from "./Widget/HeroBannerLeftLayout/herobannerleftlayout.component";
import {HeroBannerRightImageComponent} from './Widget/HeroBannerRightImage/herobanner.rightimage.component';
import {IconLayoutComponent} from './Widget/IconLayout/iconlayout.component';
import {StarRatingComponent} from './Widget/StarRating/starrating.component';
import {HeroBannerCarouselComponent} from './Widget/HeroBannerCarousel/herobanner.carousel.component';

import { CardGalleryComponent } from './Widget/card-gallery/card-gallery.component';
import { HeroBannerImageClickableComponent } from './Widget/HeroBannerImageClickable/hero-banner-image-clickable.component';
import { TableComparisonComponent } from './Widget/table-comparison/table-comparison.component';
import { DetailBannerTextLeftComponent } from './Widget/DetailBannerTextLeft/DetailBannerTextLeft.component';
import { DetailBannerTextRightComponent } from './Widget/DetailBannerTextRight/DetailBannerTextRight.component';
import { BannerWithTableLeftComponent } from './Widget/banner-with-table-left/banner-with-table-left.component';
import { BannerWithTableRightComponent } from './Widget/banner-with-table-right/banner-with-table-right.component';
import { ProductBannerMegaComponent } from './Widget/product-banner-mega/product-banner-mega.component';
import { TableWithoutHeadingComponent } from './Widget/table-without-heading/table-without-heading.component';
import { CardGalleryCarouselComponent } from './Widget/card-gallery-carousel/card-gallery-carousel.component';
import { CallOutIconComponent } from './Widget/call-out-icon/call-out-icon.component';
import { CollageComponent } from './Widget/collage/collage.component';
import { DetailBannerLinkoutComponent } from './Widget/detail-banner-linkout/detail-banner-linkout.component';
import { VideoBannerComponent } from './Widget/video-banner/video-banner.component';
import { TestimonialsComponent } from './Widget/testimonials/testimonials.component';
import { ImgaeCardOverlayComponent } from './Widget/imgae-card-overlay/imgae-card-overlay.component';
import { ProductBannerTextLeftComponent } from './Widget/product-banner-text-left/product-banner-text-left.component';
import { DeviceCarouselComponent } from './Widget/device-carousel/device-carousel.component';
import { ImageCard3Component } from './Widget/image-card3/image-card3.component';
//import { ProductBannerTextCenterComponent } from './Widget/product-banner-text-center/product-banner-text-center.component';
import { TabNavigationComponent } from './Widget/tab-navigation/tab-navigation.component';
import { AccordianComponent } from './Widget/accordian/accordian.component';
import { SearchHeaderComponent } from './Widget/search-header/search-header.component';
import { SearchBarComponent } from './Widget/search-bar/search-bar.component';
import { SearchFindingsComponent } from './Widget/search-findings/search-findings.component';
import { TitleBoxLinkComponent } from './Widget/title-box-link/title-box-link.component';
import {AppWidgetDirective}  from './app.widget.directive';
import {faqBannerComponent} from './Widget/faqBanner/faqBanner.component';
import {FeedbackComponent} from './Widget/feedback/feedback.component';
//ibm-moudules
import { AccordionModule } from './Widget/accordion-ibm/accordion.module'
import { IconItemModule } from './Widget/IconItem/icon-item-module'
import { OutageComponent } from './Widget/outage/outage.component';
import { MultistepsComponent } from './Widget/multisteps/multisteps.component';
//import { HeroBannerRightLayoutComponent } from './Widget/HeroBannerRightLayout/HeroBannerRightLayout.component';
import { HttpModule } from '@angular/http';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    SubNavigationComponent,
    FooterComponent,
    SocialMediaComponent,
    ProductCardComponent,    
    HeroBannerRightImageComponent,
    IconLayoutComponent,
    StarRatingComponent,
    HeroBannerCarouselComponent,
    CardGalleryComponent,
    HeroBannerImageClickableComponent,
    TableComparisonComponent,
    DetailBannerTextRightComponent,
    BannerWithTableLeftComponent,
    BannerWithTableRightComponent,
    BreadcrumbComponent,
    ProductBannerMegaComponent,
    TableWithoutHeadingComponent,
    CardGalleryCarouselComponent,
    CallOutIconComponent,
    CollageComponent,
    DetailBannerLinkoutComponent,
    VideoBannerComponent,
    TestimonialsComponent,    
    DetailBannerTextLeftComponent,
    ImgaeCardOverlayComponent,
    ProductBannerTextLeftComponent,
    DeviceCarouselComponent,
    ImageCard3Component,
    TabNavigationComponent,
    AccordianComponent,
    SearchHeaderComponent,
    SearchBarComponent,
    SearchFindingsComponent,
    TitleBoxLinkComponent,    
    AppWidgetDirective,
    faqBannerComponent,
    OutageComponent,
    FeedbackComponent,
    //HeroBannerRightLayoutComponent,
    HeroBannerLeftLayoutComponent,
    MultistepsComponent

  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'universal' }),
    HttpClientModule,
    HttpModule,
    FormsModule,
    NgxCarouselModule,
    AccordionModule,
    IconItemModule,
    SharedModule,
    StoreModule,
    RouterModule.forRoot(router)    
  ],
  entryComponents:[
    StarRatingComponent,
    IconLayoutComponent, 
    HeroBannerCarouselComponent,
    ProductCardComponent,
    HeroBannerImageClickableComponent,
    HeroBannerRightImageComponent,
    faqBannerComponent,
    AccordianComponent,
    DetailBannerTextLeftComponent,
    DetailBannerTextRightComponent,
    ProductBannerMegaComponent,
    CollageComponent,
    CallOutIconComponent,
    DetailBannerLinkoutComponent,
    BannerWithTableLeftComponent,
    BannerWithTableRightComponent,
    TableComparisonComponent,
    TabNavigationComponent,
    //HeroBannerRightLayoutComponent,
    HeroBannerLeftLayoutComponent,
    MultistepsComponent
  ],
  providers: [AppService,RoutesService,Broadcaster,NotificationPopupEvent],
  bootstrap: [AppComponent]
})
export class AppModule {  
  private MY_ROUTE:string = "MY_ROUTE";
  private MyAppRoutes:Array<any>;
  
  constructor(private routesservice: RoutesService,private _router:Router){   
    this.MyAppRoutes = [];
    //this.RemoveLocalStorage();
    //this.FindAppRoutes();
  }  
  private FindAppRoutes() {
    this.routesservice.Find().subscribe((data:any)=>{  
      this.ManagedynamicRoute(data);
    });
  }

  private ManagedynamicRoute(routeData){
    routeData.forEach((item:any) => {
      item.alias = item.alias.substr(1);
      this.MyAppRoutes.push({ 
        path: item.alias, 
        component : HomeComponent,
        data:{"EndPoint":item.end_point}
      });
      this.AddRouteToLocalStorage(routeData);    
    });
    this._router.resetConfig(this.MyAppRoutes);        
    
  }
  private RemoveLocalStorage(){
    //if exist..
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.MY_ROUTE);
    }
  }
  private AddRouteToLocalStorage(data){
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.MY_ROUTE,JSON.stringify(data));
    }
    
  }
  
}



//Angular Universal...
//https://www.youtube.com/watch?v=lncsmB5yfzE
//cousetro.com
//For Dyanmic Routing...
//https://github.com/angular/angular-cli/issues/4234