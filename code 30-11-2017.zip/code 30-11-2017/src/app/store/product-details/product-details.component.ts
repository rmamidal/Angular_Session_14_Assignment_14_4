import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  public id:any;
  public selectedProduct = {};
  productDetails2 = [
    {
        "ProductText": "Mi A1 (Rose Gold, 64 GB)",
        "id":1,
        "position": 0,
        "category_id": "4",
        "spec": "4GB RAM",
        "rating": "84,851 Rating & 19,869 Reviews",
        "price" : "8500",
        "img" : "https://rukminim1.flixcart.com/image/312/312/ja73ki80/mobile/9/m/s/mi-mi-a1-mzb5654in-original-imaeztu5hhvydshh.jpeg?q=70"
    },
    {
        "ProductText": "Redmi Note 4 (Gold, 32 GB)",
        "id":2,
        "position": 0,
        "category_id": "4",
        "spec": "16GB RAM",
        "rating": "84,851 Rating & 19,869 Reviews",
        "price" : "9999",
        "img" : "https://rukminim1.flixcart.com/image/312/312/mobile/y/u/a/mi-redmi-note-4-na-original-imaeqdxgrdhxgkcx.jpeg?q=70"
    },
    {
        "ProductText": "Mi A1 (Gold, 64 GB)",
        "id":3,
        "position": 0,
        "category_id": "4",
        "spec": "8GB RAM",
        "rating": "84,851 Rating & 19,869 Reviews",
        "price" : "12,500",
        "img" :"https://rukminim1.flixcart.com/image/312/312/j6wi0sw0/mobile/d/6/n/mi-redmi-4a-mzb5602in-original-imaex8mpswmhes6x.jpeg?q=70"
    }
]
constructor(private route: ActivatedRoute, private router: Router) {

}
ngOnInit() {
this.id = this.route.params.subscribe(params => {
    let id = params['id'];
    this.productDetails2.forEach(function(item, index) {
      if(item.id == id) {
        this.selectedProduct.ProductText = item.ProductText;
        this.selectedProduct.KeyFiguresText = item.KeyFiguresText;
        this.selectedProduct.KeyText = item.KeyText;
        this.selectedProduct.img = item.img;
        this.selectedProduct.price = item.price;
      }
    }.bind(this));
    if(Object.keys(this.selectedProduct).length == 0) {
      this.router.navigate(['/']);
    }
  });
}
}
