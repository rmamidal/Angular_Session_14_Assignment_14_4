import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
    productDetails = [
        {
            "ProductText": "Mi A1 (Rose Gold, 64 GB)",
            "id":1,
            "position": 0,
            "category_id": "4",
            "spec": "4GB RAM",
            "rating": "84,851 Rating & 19,869 Reviews",
            "price" : "8500",
            "img" : "https://rukminim1.flixcart.com/image/312/312/ja73ki80/mobile/9/m/s/mi-mi-a1-mzb5654in-original-imaeztu5hhvydshh.jpeg?q=70"
        },
        {
            "ProductText": "Redmi Note 4 (Gold, 32 GB)",
            "id":2,
            "position": 0,
            "category_id": "4",
            "spec": "16GB RAM",
            "rating": "84,851 Rating & 19,869 Reviews",
            "price" : "9999",
            "img" : "https://rukminim1.flixcart.com/image/312/312/mobile/y/u/a/mi-redmi-note-4-na-original-imaeqdxgrdhxgkcx.jpeg?q=70"
        },
        {
            "ProductText": "Mi A1 (Gold, 64 GB)",
            "id":3,
            "position": 0,
            "category_id": "4",
            "spec": "8GB RAM",
            "rating": "84,851 Rating & 19,869 Reviews",
            "price" : "12,500",
            "img" :"https://rukminim1.flixcart.com/image/312/312/j6wi0sw0/mobile/d/6/n/mi-redmi-4a-mzb5602in-original-imaex8mpswmhes6x.jpeg?q=70"
        }
    ]
  constructor() { }

  ngOnInit() {
  }

}
