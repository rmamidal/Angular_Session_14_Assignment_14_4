
import { Routes } from '@angular/router';

import { ProductComponent } from './product/product.component';


export const appRoutes: Routes = [
    { path: 'store', component: ProductComponent },
];