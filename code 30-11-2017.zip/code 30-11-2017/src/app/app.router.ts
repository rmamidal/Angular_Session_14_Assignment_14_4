import {ModuleWithProviders} from '@angular/core';
import {Routes,RouterModule,Router} from '@angular/router';

import {HomeComponent} from './Home/home.component';
import { ProductComponent } from './store/product/product.component';
import { ProductDetailsComponent } from './store/product-details/product-details.component';


export const router:Routes =[
    {path:"",pathMatch:"full",component:HomeComponent,data:{"EndPoint":""}},
   // {path:"**",component:HomeComponent,data:{"EndPoint":"","Star":"*"}},
    {path:"store",component:ProductComponent},
    { path: 'productDetails/:id', component: ProductDetailsComponent },
    
    //{path:"home",component:HomeComponent,data:{Id:"/Home/Api",TemplateName:"Home"}}   
];

//export const routes:ModuleWithProviders = RouterModule.forRoot(router);
