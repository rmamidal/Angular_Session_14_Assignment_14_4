import { Component, OnInit,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BannerWithTableLeftService} from "./banner-with-table-left.service";
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-banner-with-table-left',
  templateUrl: './banner-with-table-left.component.html',
  styleUrls: ['./banner-with-table-left.component.css'],
  providers: [BannerWithTableLeftService, RedirectionService]
})
export class BannerWithTableLeftComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  BannerWithTableleftBuyNowData :any;
  TableData:any;


  constructor(private _service:BannerWithTableLeftService, 
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();
   }

  ngOnInit(){
    this.Init();
  }

  private Init() { 
    if(this.data && this.data.Api != undefined){
      this._service.FindBuyNowSectionForTableLeft(this.data.Api).subscribe(
        (response)=>{
        this.BannerWithTableleftBuyNowData = response['Items'][0];
        this.BannerWithTableleftBuyNowData.BannerImage = this.ApiUrl + this.BannerWithTableleftBuyNowData.BannerImage;
        this.BannerWithTableleftBuyNowData.ForegroundImage = this.ApiUrl + this.BannerWithTableleftBuyNowData.ForegroundImage;
        if(this.BannerWithTableleftBuyNowData.ButtonText != '') {
          this.BannerWithTableleftBuyNowData.SetDisplay = "block";
        }
        else {
          this.BannerWithTableleftBuyNowData.SetDisplay = "none";
        }
        this.TableData = this.BannerWithTableleftBuyNowData.TableData;      
        });
    }
  }
  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}
