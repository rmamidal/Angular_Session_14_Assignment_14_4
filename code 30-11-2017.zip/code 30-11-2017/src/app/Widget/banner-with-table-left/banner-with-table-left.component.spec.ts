import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BannerWithTableLeftComponent } from './banner-with-table-left.component';

describe('BannerWithTableLeftComponent', () => {
  let component: BannerWithTableLeftComponent;
  let fixture: ComponentFixture<BannerWithTableLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BannerWithTableLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BannerWithTableLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
