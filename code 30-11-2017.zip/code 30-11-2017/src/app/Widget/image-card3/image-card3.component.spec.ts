import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageCard3Component } from './image-card3.component';

describe('ImageCard3Component', () => {
  let component: ImageCard3Component;
  let fixture: ComponentFixture<ImageCard3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImageCard3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageCard3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
