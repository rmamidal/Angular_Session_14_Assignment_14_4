import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'
import {TableComparisionService} from './table-comparison.service'

@Component({
  selector: 'app-table-comparison',
  templateUrl: './table-comparison.component.html',
  styleUrls: ['./table-comparison.component.css'],
  providers:[RedirectionService, TableComparisionService]
})
export class TableComparisonComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public TableComparisonResponse = null;
  temp:any;

  constructor(
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService,
    private _service:TableComparisionService
  ){
    super();
   
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {     
    if(this.data && this.data.Api != undefined){   
      // let url = "/"+ this.data.Api + "?_format=hal_json"; 
      let url = 'http://localhost:8085/json/plan_list.json'; 
      this._service.Find(url).subscribe(
        (response:any)=> {           
          console.log(response);
          
          this.TableComparisonResponse=response;             
          this.TableComparisonResponse.forEach((itemParent:any,index) => { 
            //////////

            let url2 = 'http://localhost:8085/json/plan/' + itemParent.sku +'.json';
            this._service.Find(url2).subscribe(
              (response:any)=> {
               // itemParent.KeyFiguresText = response.price;
                itemParent.KeyText = "RS:" +response.price;
              });

            ///////
            itemParent.BackgroundColor = "is-bg-color-white";
            itemParent.IndicatorClass = "is-level-gold";
            itemParent.ProductText = itemParent.sku;
            itemParent.knowMoreText = "Switch now";
            itemParent.BuynowText =  "Learn more";
            itemParent.TableInfo = [];
            //////////
            itemParent.AtrHref="#rm-"+index;
            itemParent.TableInfo.forEach((item:any,index) => {   
                item.Id = index;
                item.HrefId="rm-"+index;     
              });    
          });
        });
      }
  }

  public ManageContentNavigation(data:any){
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}
