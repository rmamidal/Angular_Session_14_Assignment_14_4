import { Component,OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";

@Component({
  selector: 'herobanner-rightimage-component',
  templateUrl: './herobanner.rightimage.component.html',
})

export class HeroBannerRightImageComponent{
  @Input() data: any;
    constructor(){

    }
}