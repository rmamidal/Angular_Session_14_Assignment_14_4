import { Component,OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {ProductCardService} from "./productcard.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'productcard-component',
  templateUrl: './productcard.component.html',
  providers:[ProductCardService,RedirectionService]
})


export class ProductCardComponent extends BaseComponent implements AppWidgetComponent   {
  @Input() data: any;
  public ProductCardResponse = null;
  
  constructor(private productcardservice: ProductCardService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService
  ){
    super();
  }

  ngOnInit(){
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api !=undefined){
      let apiUrl:string = "/" + this.data.Api + "?_format=hal_json";    
      
      this.productcardservice.Find(apiUrl.trim()).subscribe(      
          (response)=>{   
              this.ProductCardResponse = response['Items'];        
              this.ProductCardResponse.forEach((item:any) => {
                //TBD call service to get url
                if(item.BrandIcon !== ""){
                  item.BrandIcon = this.ApiUrl + item.BrandIcon;
                }
              });
          });
    }
  }
  public ManageContentNavigation(data:any){              
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}