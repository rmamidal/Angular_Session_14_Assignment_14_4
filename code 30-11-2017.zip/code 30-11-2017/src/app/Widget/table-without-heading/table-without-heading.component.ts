import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-table-without-heading',
  templateUrl: './table-without-heading.component.html',
  styleUrls: ['./table-without-heading.component.css']
})
export class TableWithoutHeadingComponent implements OnInit {
  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

}
