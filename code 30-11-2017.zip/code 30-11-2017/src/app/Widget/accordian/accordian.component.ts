import { Component, OnInit, Input } from '@angular/core';
import {AccordianService} from './accordian.service';
@Component({
  selector: 'cc-accordian',
  templateUrl: './accordian.component.html',
  styleUrls: ['./accordian.component.css'],
  providers:[AccordianService]
})
export class AccordianComponent implements OnInit {
  @Input() data: any;
  public AccordionData = null;
  public TabNavigationData: any;
  public SelectedTab: string = ''; 
  public AccordionDataByTab: any; 
  constructor(private _service:AccordianService) { 
    this.TabNavigationData= [];
  }

  ngOnInit() {    
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this._service.Find(apiUrl).subscribe(
        (response:any)=>{          
          if(response.data.length > 0){     
            this.AccordionData = response.data;    
            this.TabNavigationData = this.FindTabNavigationData(this.AccordionData);
            this.SelectedTab = this.TabNavigationData[0].Term;
            this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab);
          }
        });
    }
  }
  public OnTabSelect(item,index){
    this.SelectedTab = item.Term;
    this.AccordionDataByTab = this.FindAccordionDataByActiveTab(this.AccordionData,this.SelectedTab);
  }
  private FindAccordionDataByActiveTab(accordionData:Array<any>,activeTab:string){
    return accordionData.filter((item:any)=>{
      return (item.Term==activeTab);
    });
  }
  private FindTabNavigationData(accordionData:Array<any>){
    let result = [];
    accordionData.filter((item:any)=>{
      if(!this.IsAlreadyExist(result,item.Term)){
        result.push({
          Term:item.Term,
          Title:item.Title
        });
      }      
    });
    return result;
  }
  private IsAlreadyExist(result:Array<any>,term:string):boolean{
    let data = result.filter((item:any)=>{
      return (item.Term==term);
    });

    if(data.length>0){
      return true;
    }
    else{
      return false;
    }
  }
}
