import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-card-gallery',
  templateUrl: './card-gallery.component.html',
  styleUrls: ['./card-gallery.component.css']
})
export class CardGalleryComponent implements OnInit {
  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

}
