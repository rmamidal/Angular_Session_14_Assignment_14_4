import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {faqBannerService} from "./faqBanner.service";
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'faqBanner-component',
  templateUrl: './faqBanner.component.html',
  providers:[faqBannerService,RedirectionService]
})
export class faqBannerComponent {
  @Input() data: any;
  public faqBannerResponse = null;
  titleColor:any;

    constructor(private faqservice:faqBannerService,
                private _router:Router,
                private _activatedRoute:ActivatedRoute,
                private _redirectionService:RedirectionService
    ){
    }

    ngOnInit(){
      this.Init();
    }

    private Init() {
          this.faqBannerResponse = this.data;
          this.titleColor = this.faqBannerResponse.TitleColor; 
          
    }

    public ManageContentNavigation(data:any){   
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
   }
}