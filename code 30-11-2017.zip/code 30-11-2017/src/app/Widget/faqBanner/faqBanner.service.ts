import {Injectable} from '@angular/core';
import {Http, RequestOptions, Headers} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';
import {AppService} from '../../Service/app.service';

@Injectable()
export class faqBannerService extends BaseService  {
    constructor(private _service:AppService){
        super();
    }

    public Find(apiURL:string):Observable<any[]>{
        
        let url= apiURL;    
        let options = this.GenerateHeader();
        
        return this._service
        .get(url)
        .map((response:any) => {
            
            return response
        })        
    }

    public FindFooter_New(){   
        let url= "/api/menu_details/footer?_format=hal_json";
        let _headers = new Headers();
        _headers.append("Content-Type","application/hal+json");
    }
}