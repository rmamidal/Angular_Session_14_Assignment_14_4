import { TestBed, inject } from '@angular/core/testing';

import { CollageService } from './collage.service';

describe('CollageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CollageService]
    });
  });

  it('should be created', inject([CollageService], (service: CollageService) => {
    expect(service).toBeTruthy();
  }));
});
