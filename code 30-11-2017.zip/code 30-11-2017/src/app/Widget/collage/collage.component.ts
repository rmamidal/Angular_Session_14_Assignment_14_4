import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {CollageService} from "./collage.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'collage',
  templateUrl: './collage.component.html',
  styleUrls: ['./collage.component.css'],
  providers:[CollageService,RedirectionService]
})
export class CollageComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public CollageResponse = null;
  public CollageParentResponse = null;
  public collageCard:any;
  public oneCollageCardClass: string;
  
  constructor(private collageservice:CollageService,public viewContainerRef: ViewContainerRef,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) {
      super();
    this.collageCard = [];
  }
 
  ngOnInit() {
    this.Init();
  }

  private Init() {    
    if(this.data && this.data.Api != undefined){
    let url = "/"+ this.data.Api + "?_format=hal_json";
    this.CollageParentResponse = this.data;
   
    this.collageservice.Find(url).subscribe(
    (response:any)=>{ 
      this.CollageResponse=response.Items;
      let collageCount = this.CollageResponse.length;

      if(collageCount == 1) {
        this.oneCollageCardClass = 'one-collage-card';
      }

      //for CalloutIcon image
      this.CollageResponse.forEach((item:any) => {
        
        if(item.iconSubtitle.length == 1 || item.iconSubtitle.length == 2){
          item.ContainerClass = "is-col-tablet-p-6";
        }        
        if(item.iconSubtitle.length == 3){
          item.ContainerClass = "is-col-tablet-p-12";          
        }
        //TBD call service to get url
        if(item.CollageIcon !== ""){
           item.CollageIcon = this.ApiUrl + item.CollageIcon;
         }
        });

      //to handle null values
      if(this.CollageResponse.Desktop == null || this.CollageResponse.Desktop == undefined){
        this.CollageResponse['Desktop'] = {
            img:''
        }
        
      }
      if(this.CollageResponse.Mobile == null || this.CollageResponse.Mobile == undefined){
        if(this.CollageResponse.Desktop.Mobile == undefined)
        {
          this.CollageResponse['Mobile'] = {
            img:''
          }
        }
      }
    });
  }
    
    
    }

    public ManageContentNavigation(data:any){ 
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);  
    }
}