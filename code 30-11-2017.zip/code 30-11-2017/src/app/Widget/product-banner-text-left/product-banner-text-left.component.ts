import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-product-banner-text-left',
  templateUrl: './product-banner-text-left.component.html',
  styleUrls: ['./product-banner-text-left.component.css']
})
export class ProductBannerTextLeftComponent implements OnInit {
  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

}
