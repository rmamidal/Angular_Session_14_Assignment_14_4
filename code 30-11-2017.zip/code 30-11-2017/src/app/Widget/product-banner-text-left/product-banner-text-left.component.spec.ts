import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBannerTextLeftComponent } from './product-banner-text-left.component';

describe('ProductBannerTextLeftComponent', () => {
  let component: ProductBannerTextLeftComponent;
  let fixture: ComponentFixture<ProductBannerTextLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBannerTextLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBannerTextLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
