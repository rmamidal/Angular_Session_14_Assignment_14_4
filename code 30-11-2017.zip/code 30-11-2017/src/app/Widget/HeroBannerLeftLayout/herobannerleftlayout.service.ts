import {Injectable} from '@angular/core';
import {Http,Headers,RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../../base.service';
import {AppService} from '../../Service/app.service';

@Injectable()
export class HeroBannerLeftLayoutService extends BaseService  {
    constructor(private _service:AppService){
        super();
    }

    public Find(apiURL:string):Observable<any[]>{                 
        let options = this.GenerateHeader();
        return this._service
        .get(apiURL)
        .map((response:any) => {
            return response
        })        
    }
}

