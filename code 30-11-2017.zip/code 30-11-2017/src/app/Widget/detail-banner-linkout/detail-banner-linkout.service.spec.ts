import { TestBed, inject } from '@angular/core/testing';

import { DetailBannerLinkoutService } from './detail-banner-linkout.service';

describe('DetailBannerLinkoutService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DetailBannerLinkoutService]
    });
  });

  it('should be created', inject([DetailBannerLinkoutService], (service: DetailBannerLinkoutService) => {
    expect(service).toBeTruthy();
  }));
});
