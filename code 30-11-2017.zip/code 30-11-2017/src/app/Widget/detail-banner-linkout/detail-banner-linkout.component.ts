import { Component, OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {DetailBannerLinkoutService } from "./detail-banner-linkout.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-detail-banner-linkout',
  templateUrl: './detail-banner-linkout.component.html',
  styleUrls: ['./detail-banner-linkout.component.css'],
  providers:[DetailBannerLinkoutService,RedirectionService]
})
export class DetailBannerLinkoutComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public detailBannerLinkOutResponse :any;
  public img:any;
  public arr:Array<string>;
  constructor( private detailbannerlinkoutservice:DetailBannerLinkoutService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService) { 
    //this.detailBannerLinkOutResponse = [];
    super();
  }

  ngOnInit() {
    this.Init();
  }
  private Init() {        
    if(this.data && this.data.Api != undefined){
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this.detailbannerlinkoutservice
      .getData(apiUrl)
      .subscribe((data:  any) => { 
      this.detailBannerLinkOutResponse = data.Items[0];
      this.detailBannerLinkOutResponse.BannerImage= this.ApiUrl + this.detailBannerLinkOutResponse.BannerImage;
      this.detailBannerLinkOutResponse.KnowMoreButtonText = this.detailBannerLinkOutResponse.KnowMoreButtonText.replace("&amp;amp;",'&');
      this.detailBannerLinkOutResponse.KnowMoreButtonText = this.detailBannerLinkOutResponse.KnowMoreButtonText.replace("&gt;",'>');
      this.detailBannerLinkOutResponse.KnowMoreButtonText = this.detailBannerLinkOutResponse.KnowMoreButtonText.replace("&lt;",'<');
      });
    }
  }
  public ManageContentNavigation(data:any){     
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);  
  }

}
