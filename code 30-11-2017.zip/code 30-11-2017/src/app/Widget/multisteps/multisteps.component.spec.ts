import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultistepsComponent } from './multisteps.component';

describe('MultistepsComponent', () => {
  let component: MultistepsComponent;
  let fixture: ComponentFixture<MultistepsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultistepsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultistepsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});