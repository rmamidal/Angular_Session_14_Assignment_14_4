import { TestBed, inject } from '@angular/core/testing';

import { MultistepsService } from './multisteps.service';

describe('MultistepsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MultistepsService]
    });
  });

  it('should be created', inject([MultistepsService], (service: MultistepsService) => {
    expect(service).toBeTruthy();
  }));
});
