import { Component, OnInit, ViewContainerRef,Input } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import "rxjs/add/operator/map";
import { AppWidgetComponent } from '../../Model/app.widget.component';
import { BaseComponent } from '../../base.component';
import { ContentNavigation } from '../../Model/contentnavigation.model'
import { ActivatedRoute,Router } from '@angular/router';
import { RedirectionService } from '../../Service/redirection.service'
import { MultistepsService } from './multisteps.service';

@Component({
  selector: 'app-multisteps',
  templateUrl: './multisteps.component.html',
  styleUrls: ['./multisteps.component.css'],
  providers: [ RedirectionService, MultistepsService]
})
export class MultistepsComponent extends BaseComponent implements AppWidgetComponent {
  @Input() data: any;
  public multistepsResponse = null;  
  
  constructor(public viewContainerRef: ViewContainerRef,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService,
    private _MultistepsService: MultistepsService
    ){
    super();
  }     

  ngOnInit() {
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
    let apiUrl = "/" + this.data.Api + "?_format=hal_json";
    this._MultistepsService.Find(apiUrl).subscribe(
      (response)=>{
        this.multistepsResponse = response['Items'][0]; 

        // logic for step count & dynamic class for center align
        let stepCount = this.multistepsResponse.Steps.length;
        this.multistepsResponse.Steps.forEach((item: any) => {
          if(stepCount == 2) {
            item.StepClass = 'is-col-tablet-p-6';
          }
          if(stepCount == 3) {
            item.StepClass = 'is-col-tablet-p-4';
          }
          if(stepCount == 4) {
            item.StepClass = 'is-col-tablet-p-3';
          }
        });       
      });  
    }
  }
  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
  }
}