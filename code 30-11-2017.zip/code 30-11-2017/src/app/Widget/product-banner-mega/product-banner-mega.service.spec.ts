import { TestBed, inject } from '@angular/core/testing';

import { ProductBannerMegaService } from './product-banner-mega.service';

describe('ProductBannerMegaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductBannerMegaService]
    });
  });

  it('should be created', inject([ProductBannerMegaService], (service: ProductBannerMegaService) => {
    expect(service).toBeTruthy();
  }));
});
