import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBannerMegaComponent } from './product-banner-mega.component';

describe('ProductBannerMegaComponent', () => {
  let component: ProductBannerMegaComponent;
  let fixture: ComponentFixture<ProductBannerMegaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBannerMegaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBannerMegaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
