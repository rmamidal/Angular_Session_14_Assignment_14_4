import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardGalleryCarouselComponent } from './card-gallery-carousel.component';

describe('CardGalleryCarouselComponent', () => {
  let component: CardGalleryCarouselComponent;
  let fixture: ComponentFixture<CardGalleryCarouselComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardGalleryCarouselComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardGalleryCarouselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
