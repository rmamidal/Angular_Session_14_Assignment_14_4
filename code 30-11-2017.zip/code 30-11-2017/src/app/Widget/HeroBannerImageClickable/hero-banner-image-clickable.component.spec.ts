import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeroBannerImageClickableComponent } from './hero-banner-image-clickable.component';

describe('HeroBannerImageClickableComponent', () => {
  let component: HeroBannerImageClickableComponent;
  let fixture: ComponentFixture<HeroBannerImageClickableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeroBannerImageClickableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeroBannerImageClickableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
