import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-tab-navigation',
  templateUrl: './tab-navigation.component.html',
  providers: [RedirectionService]
})

export class TabNavigationComponent extends BaseComponent implements OnInit {
  @Input() data: any;
  public TabNavigationResponse = null;

    constructor(private _router: Router,
      private _activatedRoute:ActivatedRoute,
      private _redirectionService:RedirectionService){
        super();
    }

    ngOnInit(){
      this.Init();
    }

    private Init() {      
      this.TabNavigationResponse = this.data;
    }

    // public tabClick(item:any) {
    //   this._router.navigate([item.Url]);
    // }

    public ManageContentNavigation(data:any){
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
   }
}
