import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFindingsComponent } from './search-findings.component';

describe('SearchFindingsComponent', () => {
  let component: SearchFindingsComponent;
  let fixture: ComponentFixture<SearchFindingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchFindingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFindingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
