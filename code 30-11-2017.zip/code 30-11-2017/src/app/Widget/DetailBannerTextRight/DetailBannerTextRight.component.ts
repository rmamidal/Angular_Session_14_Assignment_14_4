import { Component, OnInit, Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {DetailBannerTextRightService} from "./DetailBannerTextRight.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

@Component({
  selector: 'app-DetailBannerTextRight',
  templateUrl: './DetailBannerTextRight.component.html',
  styleUrls: ['./DetailBannerTextRight.component.css'],
  providers: [DetailBannerTextRightService, RedirectionService]
})

export class DetailBannerTextRightComponent extends BaseComponent implements AppWidgetComponent {
  @Input() data: any;
  public DetailBannerTextRightResponse = null;
  
  constructor(private detailbannertextrightservice:DetailBannerTextRightService,
    private _router:Router,
    private _activatedRoute:ActivatedRoute,
    private _redirectionService:RedirectionService){
      super();
  }


  ngOnInit(){
    this.Init();
  }

  private Init() {
    if(this.data && this.data.Api != undefined){
      let apiUrl = "/" + this.data.Api + "?_format=hal_json";
      this.detailbannertextrightservice.Find(apiUrl).subscribe(
        (response)=>{
          this.DetailBannerTextRightResponse = response[0];
          this.DetailBannerTextRightResponse.BannerImage = this.ApiUrl +this.DetailBannerTextRightResponse.BannerImage;
          this.DetailBannerTextRightResponse.MobileImage = this.ApiUrl +this.DetailBannerTextRightResponse.MobileImage;
        });
    }
  }

  public ManageContentNavigation(data:any){   
    let obj= new ContentNavigation().ManagePageRedirection(data);
    this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
 }
}
