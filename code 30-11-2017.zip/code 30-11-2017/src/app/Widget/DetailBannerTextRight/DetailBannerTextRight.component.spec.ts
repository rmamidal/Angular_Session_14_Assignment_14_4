import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailBannerTextRightComponent } from './DetailBannerTextRight.component';

describe('DetailBannerTextRightComponent', () => {
  let component: DetailBannerTextRightComponent;
  let fixture: ComponentFixture<DetailBannerTextRightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailBannerTextRightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailBannerTextRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
