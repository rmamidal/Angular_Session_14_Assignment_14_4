import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-device-carousel',
  templateUrl: './device-carousel.component.html',
  styleUrls: ['./device-carousel.component.css']
})
export class DeviceCarouselComponent implements OnInit {
  @Input() data: any;
  constructor() { }

  ngOnInit() {
  }

}
