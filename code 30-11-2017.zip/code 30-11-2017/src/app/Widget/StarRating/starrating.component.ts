import { Component,OnInit,ViewContainerRef,Input } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {StarRatingService} from "./starrating.service";
import {AppWidgetComponent} from '../../Model/app.widget.component';
import {BaseComponent} from '../../base.component';
import {ContentNavigation} from '../../Model/contentnavigation.model'
import {ActivatedRoute,Router} from '@angular/router';
import {RedirectionService} from '../../Service/redirection.service'

//
import {NgxCarousel} from 'ngx-carousel';
//
@Component({
  selector: 'starrating-component',
  templateUrl: './starrating.component.html',
  providers:[StarRatingService,RedirectionService]
})
export class StarRatingComponent extends BaseComponent implements AppWidgetComponent {
  @Input() data: any;
  //
  public carouselOne: NgxCarousel;
  public carouselButton:Array<number>=[];
  carousel1Items = 		[
			{
				text: '111The Internet is so fast, Youll be surprised',
				imgUrl: './assets/img/testimonial-adam.png'
			},
			{
				text: '222Hello Savings, Good By big bills',
				imgUrl: './assets/img/testimonial-adam.png'
			},
			{
				text: '333the Internet is so fast, Youll be surprised',
				imgUrl: './assets/img/testimonial-adam.png'
      },
      {
				text: '4The Internet is so fast, Youll be surprised',
				imgUrl: './assets/img/testimonial-adam.png'
			},
			{
				text: '5Hello Savings, Good By big bills',
				imgUrl: './assets/img/testimonial-adam.png'
			},
			{
				text: '6the Internet is so fast, Youll be surprised',
				imgUrl: './assets/img/testimonial-adam.png'
			}			
	];

  //
  public StarRatingResponse = null;

    constructor(private starratingservice:StarRatingService,
      private _router:Router,
      private _activatedRoute:ActivatedRoute,
      private _redirectionService:RedirectionService
    ){
      super();
    }

    ngOnInit(){
      this.carouselOne = {
        grid: {xs: 1, sm: 1, md: 1, lg: 1, all: 0},
        //grid: {xs: 2, sm: 3, md: 3, lg: 4, all: 0},
        interval: 4000,
        point: {
         visible: true
        },
        touch: true,
        loop: true
      }
  
      this.Init();
    }
    public myfunc(event: Event) {
      this.carousel1Items.forEach((item,index) => {
        this.carouselButton.push((index+1));
      });
      
      // carouselLoad will trigger this funnction when your load value reaches
      // it is helps to load the data by parts to increase the performance of the app
      // must use feature to all carousel
    }
  

    private Init() {
      if(this.data && this.data.Api != undefined){
        let apiUrl = "/" + this.data.Api + "?_format=hal_json";
        this.starratingservice.Find(apiUrl).subscribe(
          (response)=>{
            this.StarRatingResponse = response['Items'][0];
            //this.StarRatingResponse.field_background_image = this.ApiUrl + this.StarRatingResponse.field_background_image;
            //this.StarRatingResponse.field_background_image = this.StarRatingResponse.field_background_image;                    
          });
      }
    }

    public ManageContentNavigation(data:any){   
      let obj= new ContentNavigation().ManagePageRedirection(data);
      this._redirectionService.HandleNavigation(obj,this._router,this._activatedRoute);        
   }
}