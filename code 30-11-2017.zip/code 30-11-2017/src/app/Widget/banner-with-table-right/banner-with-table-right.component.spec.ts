import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BannerWithTableRightComponent } from './banner-with-table-right.component';

describe('BannerWithTableRightComponent', () => {
  let component: BannerWithTableRightComponent;
  let fixture: ComponentFixture<BannerWithTableRightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BannerWithTableRightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BannerWithTableRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
