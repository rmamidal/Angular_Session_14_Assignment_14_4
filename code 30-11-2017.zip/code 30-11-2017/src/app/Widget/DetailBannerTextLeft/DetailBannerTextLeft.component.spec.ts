import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailBannerTextLeftComponent } from './DetailBannerTextLeft.component';

describe('DetailBannerTextLeftComponent', () => {
  let component: DetailBannerTextLeftComponent;
  let fixture: ComponentFixture<DetailBannerTextLeftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailBannerTextLeftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailBannerTextLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
