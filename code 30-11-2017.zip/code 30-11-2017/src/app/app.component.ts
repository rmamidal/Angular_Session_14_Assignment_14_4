import { Component } from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], 
})
export class AppComponent {
  title = 'app';
  componetData: any;
  RoutesData: any;

  // constructor(private routesservice: RoutesService){   
    constructor() {
    // this.routesInit();
  }
  

  // private routesInit() {
  //   this.routesservice.Find().subscribe((data)=>{
  //     this.RoutesData = data;
  //     console.log(this.RoutesData); 
  // });
  // }
}
