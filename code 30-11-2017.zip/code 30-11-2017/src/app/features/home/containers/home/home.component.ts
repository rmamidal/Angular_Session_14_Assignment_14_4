import {Component, OnInit} from '@angular/core';
import {NgxCarousel} from 'ngx-carousel';

@Component({
	selector: 'cc-app-home',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

	public carouselOne: NgxCarousel;

	public nav_list = [
		{
			navText: 'Rolloutmanagement',
			routerLink: '/dashboard'
		},
		{
			navText: 'Blueprints',
			routerLink: '/dashboard'
		}
	];

	carousel1Items = [
		[
			{
				text: 'The Internet is so fast, Youll be surprised',
				imgUrl: '/src/assets/img/svg/icons-layout/icon-speed-pink.svg'
			},
			{
				text: 'Hello Savings, Good By big bills',
				imgUrl: '/src/assets/img/svg/icons-layout/icon-hand-pink.svg'
			},
			{
				text: 'the Internet is so fast, Youll be surprised',
				imgUrl: '/src/assets/img/svg/icons-layout/icon-receive-pink.svg'
			}
		],
		[
			{
				text: 'Strong 4G network everywhere',
				imgUrl: '/src/assets/img/svg/icons-layout/icon-gift-pink.svg'
			},
			{
				text: 'the Internet is so fast, Youll be surprised',
				imgUrl: '/src/assets/img/svg/icons-layout/icon-receive-pink.svg'
			}
		]
	];

	ngOnInit() {
		this.carouselOne = {
			grid: {xs: 1, sm: 1, md: 1, lg: 1, all: 0},
			interval: 4000,
			point: {
				visible: true
			},
			touch: true,
			loop: false
		}
	}

	public myfunc(event: Event) {
		// carouselLoad will trigger this funnction when your load value reaches
		// it is helps to load the data by parts to increase the performance of the app
		// must use feature to all carousel
	}

}
