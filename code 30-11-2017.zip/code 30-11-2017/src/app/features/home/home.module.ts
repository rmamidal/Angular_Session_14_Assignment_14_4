import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { SharedModule } from '../../../app/shared/shared.module';
//import 'hammerjs';
import { NgxCarouselModule } from 'ngx-carousel';
import { AccordionModule } from '../../shared/modules/accordion/accordion.module';
import {IconItemModule} from '../components/icon-item/icon-item.module';
import { HomeComponent } from './containers/home/home.component';

@NgModule({
	imports: [
		CommonModule,
		RouterModule,
		NgxCarouselModule,
		AccordionModule,
		SharedModule,
		IconItemModule
	],
	declarations: [HomeComponent],
	exports: [
		HomeComponent
	]
})
export class HomeModule {
}
