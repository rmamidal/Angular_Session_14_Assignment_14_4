import { Component, Input } from '@angular/core';

@Component({
	selector: 'cc-icon-item',
	templateUrl: './icon-item.component.html',
	styleUrls: ['./icon-item.component.scss']
})

export class IconItemComponent {
	@Input()
	text;

	@Input()
	imageUrl;
}
