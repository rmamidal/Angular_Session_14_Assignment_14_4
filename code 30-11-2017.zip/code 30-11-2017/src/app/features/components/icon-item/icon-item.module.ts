import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { IconItemComponent } from './icon-item.component';

@NgModule({
	imports: [
		CommonModule
	],
	declarations: [
		IconItemComponent
	],
	exports: [
		IconItemComponent
	]
})

export class IconItemModule {
}
