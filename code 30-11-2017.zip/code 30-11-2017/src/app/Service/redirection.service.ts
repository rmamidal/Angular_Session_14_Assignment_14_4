import {Injectable} from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {ContentNavigationInfo} from '../Model/contentnavigation.model'
import {NotificationPopupEvent} from '../Service/broadcaster.service';
import {Broadcaster} from '../Model/broadcaster.model';

@Injectable()
export class RedirectionService {
    private MY_ROUTE:string = "MY_ROUTE";
    constructor(
        private broadcaster: Broadcaster,
        private notificationEvent: NotificationPopupEvent
    ){}

    public HandleNavigation(obj:ContentNavigationInfo,_router:Router,_activatedRoute:ActivatedRoute){
        if(obj.IsHttpOrHttps) {              
            if(!(obj.IsUrlContainsBetaWebSiteLink)){
                let data ={
                    Type:"OPEN",
                    Data:obj
                }                
                this.notificationEvent.fire(data);
            }
            else{
                window.location.href = obj.Url; 
            }
        }
        else{              
            _router.navigate([obj.Url]);                      
        }
    }

    private SetCurrentRouteToLocalStorageAndNavigate(alias:string,_router:Router){
        let data:any = '';
        if (typeof window !== 'undefined') {
            data = JSON.parse(localStorage.getItem(this.MY_ROUTE));   
        }                            
        let result:any = data.filter((item:any) => {
          return (item.alias.toLowerCase() == alias.toLowerCase())
        });          
        if(result.length>0){
            let curretRoute = result[0];
            if (typeof window !== 'undefined') {
                localStorage.setItem("current-route",JSON.stringify(curretRoute));    
            }                           
            _router.navigate([alias]);            
        }


    } 

    
}