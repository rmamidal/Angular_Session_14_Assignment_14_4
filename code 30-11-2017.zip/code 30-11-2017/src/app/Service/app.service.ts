import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';

@Injectable()
export class AppService {  

  constructor(private http: HttpClient) { 
  }
 
  // Fetch Resource
  get(endpoint: string){
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");
  	return this.http.get('https://beta.celcom.com.my'+ endpoint,{headers: _headers});
  }

   // Fetch Resource
   getEstoreData(endpoint: string){
    let _headers = new HttpHeaders();
    _headers.append("Content-Type","application/hal+json");
  	return this.http.get(endpoint,{headers: _headers});
  }

}