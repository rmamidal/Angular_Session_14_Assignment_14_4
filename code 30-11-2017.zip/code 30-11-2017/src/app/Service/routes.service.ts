import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../base.service';
import {AppService} from './app.service'

@Injectable()
export class RoutesService extends BaseService  {
    constructor(private _service:AppService){
        super();
    }

    public Find():Observable<any[]>{
        const endPointURL = '/api/uri/alias?_format=hal_json';
        let options = this.GenerateHeader();        
        return this._service
        .get(endPointURL)
        .map((response:any) => {           
            return response
        })        
    }

    
    
}