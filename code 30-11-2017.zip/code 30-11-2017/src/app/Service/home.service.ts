import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../base.service';
import {AppService} from '../Service/app.service'

@Injectable()
export class HomeService extends BaseService  {
    constructor(private _service:AppService){
            super();
    }

    public FindTemplateComponents(endPoint:string):Observable<any[]>{
    
        let url= "/" + endPoint + "?_format=hal_json";
    
        return this._service
        .get(url)
        .map((response:any) => {
            return response
        })
    }

    public FindApiEndPointInformation(data:any,alias:string){
        let result = data.filter((item:any) => {
          return (item.alias == alias)
        });          
        return result[0];
    }
    public ManageConfigurableScripts(data:any){
        data.forEach((item:any) => {
            let scriptType = item.type.toLowerCase();
            let splitResult = item.value.split(','); //'<script>alert("hi");</script>/n<script src="temp"></script>'.split('/n');
            if(scriptType == "header_script"){
                if (typeof document !== 'undefined') {
                    let head = document.getElementsByTagName('head').item(0);
                    this.AppendHeaderScript(head,splitResult);
                }
            }
            //footer_script
            if(scriptType == "footer_script"){
                if (typeof document !== 'undefined') {
                    let body = document.getElementsByTagName('body').item(0);
                    this.AppendHeaderScript(body,splitResult);
                }
            }
          });
    }
    private AppendHeaderScript(selector, arr) {
        this.AppendScript(selector,arr);
    }
    private AppendBodyScript(selector, arr) {
        this.AppendScript(selector,arr);
    }
    private AppendScript(selector, arr) {
        var content = arr;
        for(var i = 0; i< content.length; i++) {
            var _content = content[i];
            var js = _content.indexOf('script');
            var src = _content.indexOf('src=');
            // Script tag.
            if(js > -1) {
                var inline = '';
                if (typeof document !== 'undefined') {
                var script = document.createElement('script');
                script.type = 'text/javascript';
                }
                if(src > -1) {
                var url = '';
                _content.replace(/src ?= ?"([^"]+)"/gi, function(res) {
                    url = res;
                    url = url.replace('src=','');
                    url = url.replace(/['"]+/g, '')
                    url = url.replace(/["']+/g, '')
                });
                script.src = url;
                } else {
                _content.replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, function(){
                    inline += arguments[1] + '\n';
                });
                script.text = inline;
                }
                selector.appendChild(script);
            }
            else {
                selector.innerHTML += _content;
            }
        }
    }
}