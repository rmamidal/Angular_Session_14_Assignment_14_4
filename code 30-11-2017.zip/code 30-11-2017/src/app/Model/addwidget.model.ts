import { Type } from '@angular/core';

export class AddWidget {
  constructor(public component: Type<any>, public data: any) {}
}
