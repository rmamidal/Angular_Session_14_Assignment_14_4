export class ContentNavigationInfo{
  //  Data:any;
    IsAngularNavigation:boolean;
    IsOldWebSideNavigation:boolean;   
    IsUrlContainsBetaWebSiteLink:boolean;
    IsHttpOrHttps:boolean;
    Url:string;
}
export class ContentNavigation{
    //Data:any;
    private OldWebSiteLink:string="www.celcom.com.my";
    private BetaWebsiteLink:string = "beta.celcom.com.my";
    private IsLinkContainsHttpOrHttps:boolean;
    private IsAngularNavigation:boolean;
    private IsOldWebSideNavigation:boolean;
    constructor(){
        
    }

    public ManagePageRedirection(data:any):ContentNavigationInfo{        
        let url:any = data; 
        let result = new ContentNavigationInfo();
        this.IsLinkContainsHttpOrHttps = this.IsUrlContainsHttpOrHttps(url);
        result.Url = url;
        
        if(this.IsLinkContainsHttpOrHttps){
            result.IsHttpOrHttps = true;
            result.IsAngularNavigation = false;
            this.IsOldWebSideNavigation = this.IsUrlContainsOldWebSiteLink(url);
            result.IsUrlContainsBetaWebSiteLink = this.IsUrlContainsBetaWebSiteLink(url);           
            result.IsOldWebSideNavigation = this.IsOldWebSideNavigation;
            if(this.IsOldWebSideNavigation){
                result.IsAngularNavigation = false;
            }
        }
        else       
        {
            result.IsUrlContainsBetaWebSiteLink = false;
            result.IsHttpOrHttps = false;
            result.IsOldWebSideNavigation = false
            result.IsAngularNavigation = true;
        }
        return result;
    }

    private NavigationInfo():void{
        return
    }
    private IsUrlContainsOldWebSiteLink(url:string):boolean{        
        let result:boolean = url.indexOf(this.OldWebSiteLink) > -1;
        return result;
    } 
    
    private IsUrlContainsBetaWebSiteLink(url:string):boolean{        
        let result:boolean = url.indexOf(this.BetaWebsiteLink) > -1;
        return result;
    } 
    
    private IsUrlContainsHttpOrHttps(navLink:string):boolean
    {
        let linkRegExpression = /(http(s?))\:\/\//gi;
        return linkRegExpression.test(navLink);        
    }
}