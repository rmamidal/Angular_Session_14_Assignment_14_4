import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import "rxjs/add/operator/map";
import {BaseService} from '../base.service';
import {AppService} from '../Service/app.service';

@Injectable()
export class HeaderService extends BaseService  {
    constructor(private _service:AppService){
            super();
    }

    public FindGlobalNavigation():Observable<any[]>{
        let url= '/api/menu_details/global-navigation?_format=json';    

        return this._service
        .get(url)
        .map((response:any) => {           
            return response
        })       
    }
}