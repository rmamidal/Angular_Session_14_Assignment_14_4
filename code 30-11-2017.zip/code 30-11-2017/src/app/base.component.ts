import {AddWidget} from './Model/addwidget.model';
import {ContentNavigation} from './Model/contentnavigation.model'
import * as environment from '../../environment.json';

export class BaseComponent {
    public ApiUrl:string=(<any>environment).nodeUrl;
    constructor(){
    }    
}