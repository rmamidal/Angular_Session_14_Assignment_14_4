import { Injectable } from '@angular/core';

/**
 * PreloaderService, control the state of the preloader.
 * Typically called by the interceptors in services.
 * @example
 *  private exale(): void {
 * 	    this.preloaderService.showPreloader();
 * 	}
 */
@Injectable()
export class MediaQueryHandler {

	private options = {
		mediaQueryProp: 'font-family',
		delay: 300
	};

	public currentMedia: string = null;

	/**
	 * Throttle method for resize events and more
	 *
	 * @param {function} func - Function which will be executed.
	 * @param {number} wait - number to wait in milliseconds.
	 * @param {boolean} immediate - execute function immediately.
	 */
	throttle(func, wait, immediate?) {
		let timeout;

		return function () {
			const context = this;
			const args = arguments;
			const callNow = immediate && !timeout;
			const later = function () {
				timeout = null;
				if (!immediate) {
					func.apply(context, args);
				}
			};

			clearTimeout(timeout);

			timeout = setTimeout(later, wait);

			if (callNow) {
				func.apply(context, args);
			}
		};
	}

	initialize() {

		// Media Query
		if (typeof document !== 'undefined') {
		const head = document.querySelectorAll('head');
		
		/**
		 * Add current media query to Veams
		 */
		this.currentMedia = window.getComputedStyle(head[0], null).getPropertyValue(this.options.mediaQueryProp);

		// Trigger global resize event
		window.onresize = this.throttle((e) => {
			const currentMedia = window.getComputedStyle(head[0], null).getPropertyValue(this.options.mediaQueryProp);

			if (currentMedia !== this.currentMedia) {
				this.currentMedia = currentMedia;

				console.info(`MediaQueryHandler :: Current media is ${this.currentMedia}`);

			}

		}, this.options.delay);
	}
}
}
