import { AfterViewInit, Component, ContentChildren, OnInit, QueryList } from '@angular/core';
import { AccordionItemComponent } from "../accordion-item/accordion-item.component";
import { Options } from "../../models/options";

@Component({
	selector: 'cc-accordion',
	templateUrl: './accordion.component.html',
	styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent implements AfterViewInit {

	public options: Options = {
		openAllOnInit: false,
		// openByHash: false,
		// openIndex: null,
		openOnViewports: [
			'tablet-s',
			'desktop-m',
			'desktop-l'
		], // array: viewport names - eg.: ['mobile', 'tablet', 'desktop-small', 'desktop']
		// removeStyles: false,
		singleOpen: false,
		 // tabMode: false,
		//unresolvedClass: 'is-unresolved',
	};

	@ContentChildren(AccordionItemComponent) accordionItemComponents: QueryList<AccordionItemComponent>;

	ngAfterViewInit() {
		if(this.options.openAllOnInit){
			this.openAll()
		}

		if(this.options.singleOpen){
			this.accordionItemComponents.toArray().forEach((item) => {
				const itemId = item.itemId;
				item.open.subscribe(() => {
						this.closeOthers(itemId);
				});
			});
		}
	}

	/**
	 * Close other items
	 *
	 * @param {string} id
	 */
	private closeOthers(id: string): void {
		this.accordionItemComponents.toArray().filter((item) => item.itemId !== id).forEach((item)=>{
			if(item.isOpen){
				item.closeItem();
			}
		});
	}

	/**
	 * Close all accordion contents and active buttons
	 *
	 * @public
	 */
	 public closeAll(): void {
		this.accordionItemComponents.toArray().forEach((item)=>{
			item.closeItem();
		});
	}

	/**
	 * Close all accordion contents and active buttons
	 *
	 * @public
	 */
	public openAll(): void {
		this.accordionItemComponents.toArray().forEach((item)=>{
			item.openItem();
		});
	}



}
