import { Component, ElementRef, EventEmitter, Input, OnInit, ViewChild } from '@angular/core';

@Component({
	selector: 'cc-accordion-item',
	templateUrl: './accordion-item.component.html',
	styleUrls: ['./accordion-item.component.scss']
})
export class AccordionItemComponent implements OnInit {

	@Input() itemId: string;
	@Input() button: string;

	@ViewChild('accordionContent') public accordionContent: ElementRef;

	public isCalculating = true;
	public isOpen = false;
	private storedHeight: number = this.elementRef.nativeElement.offsetHeight;
	public height: number = null;
	public open = new EventEmitter<boolean>(false);

	constructor(public elementRef: ElementRef) {
	}

	ngOnInit() {
		this.storedHeight = this.accordionContent.nativeElement.offsetHeight;
		this.isCalculating = false;
	}

	toggleItem(): void {
		if(this.isOpen){
			this.setStateClose();
			this.closeItem()
		} else {
			this.setStateOpen();
			this.openItem()
		}
	}

	setStateOpen(){
		this.open.emit(true);
	}

	setStateClose(){
		this.open.emit(false);
	}

	/**
	 * Open this item
	 */
	openItem(): void {
		console.log('wantedHeight: ', this.storedHeight);
		this.isOpen = true;
		this.height = this.storedHeight;
	}

	/**
	 * Close this item
	 */
	closeItem(): void {
		this.isOpen = false;
		this.height = 0;
	}

}
