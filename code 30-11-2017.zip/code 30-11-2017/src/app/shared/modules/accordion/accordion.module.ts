import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AccordionItemComponent } from './components/accordion-item/accordion-item.component';
import { AccordionComponent } from './components/accordion/accordion.component';

@NgModule({
	imports: [
		CommonModule
	],
	declarations: [
		AccordionComponent,
		AccordionItemComponent
	],
	exports: [
		AccordionComponent,
		AccordionItemComponent
	]
})
export class AccordionModule {
}
