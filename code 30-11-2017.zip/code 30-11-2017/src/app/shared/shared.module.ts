import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ErrorPageComponent } from './components/error-page/error-page.component';
import { GlobalNavigationComponent } from './components/global-navigation/global-navigation.component';

@NgModule({
	imports: [
		CommonModule,
		RouterModule
	],
	declarations: [
		GlobalNavigationComponent,
		ErrorPageComponent
	],
	exports: [
		GlobalNavigationComponent,
		ErrorPageComponent
	],
	providers: []
})
export class SharedModule {
}
