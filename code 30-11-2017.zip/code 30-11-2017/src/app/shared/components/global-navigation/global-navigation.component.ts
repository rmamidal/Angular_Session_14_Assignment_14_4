import {Component, Input, OnInit} from '@angular/core';

@Component({
	selector: 'cc-global-navigation',
	templateUrl: './global-navigation.component.html',
	styleUrls: ['./global-navigation.component.scss']
})
export class GlobalNavigationComponent implements OnInit {

	@Input() navList: any[];

	constructor() {
	}

	ngOnInit() {
	}

}
